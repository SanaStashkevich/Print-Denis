<?php

/* @var $this yii\web\View */

$this->title = 'My Yii Application';
?>
<div class="site-index">

    <? include_once "_o-nas.php" ?>
    <? include_once "_products.php" ?>
    <? include_once "_requirements_for_model.php" ?>
    <? include_once "_delivery_and_payment.php" ?>
    <? include_once "_contacts.php" ?>

</div>
